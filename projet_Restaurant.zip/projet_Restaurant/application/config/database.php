<?php

/*
 * Database configuration settings used by PDO.
 */

$config['dsn']      = 'mysql:dbname=restaurant;host=localhost;charset=utf8';
$config['password'] = 'troiswa';
$config['user']     = 'root';