<?php

	class InscriptionForm extends Form
	{

		public function build()
		{
			$this->addFormField('nom');
	        $this->addFormField('prenom');
	        $this->addFormField('password');
	        $this->addFormField('email');
	        $this->addFormField('telephone');
	        $this->addFormField('adresse');
	        $this->addFormField('cp');
	        $this->addFormField('ville');
	    }
	}
?>