<?php 

class UserModel{

	private $_db;
	private $_sql;


	public function __construct()
	{
		$this->_db = new Database();
	}


	public function create($email,$nom, $prenom, $password, $telephone, $adresse, $cp, $ville)
	{
		$_sql = 'SELECT * 
		FROM Client 
		WHERE email = ?';
		$user = $this->_db->queryOne($_sql, [$email]);
		var_dump($user);

		if($user !== false)
		{
			throw new DomainException
			(
				"Il n'y a pas de compte utilisateur associé à cette adresse email et/ou ce mot de passe"
			);
		}else
		{
			$_sql = 'INSERT INTO Client (email,nom, prenom, password, telephone, adresse, cp, ville) VALUES(?,?,?,?,?,?,?,?)';

			$password = password_hash($password, PASSWORD_DEFAULT);
			// $ab=[$nom, $prenom, $password, $email, $telephone, $adresse, $cp, $ville];
			// var_dump($ab); exit();
			$result = $this->_db->executeSql($_sql, [$email, $nom, $prenom, $password, $telephone, $adresse, $cp, $ville]);
			var_dump($result);
			return $result;
			
		}

	}

	public function findWithEmailPassword($email, $password)
	{
		$_sql =
			"SELECT idClient, prenom, nom, email, password
			FROM Client
			WHERE email = ?";
			$user = $this->_db->queryOne($_sql, [$email]);

			$usermail = $user['email'];
			$usermdp = $user['password'];

		if($usermail != '' && password_verify($password, $usermdp)){

			
		}
		else
		{
			throw new DomainException
			(
				"Il n'y a pas de compte utilisateur associé à cette adresse email et/ou ce mot de passe"
			);
			
		}
		return $user;
	}
}

?>




































































<!-- /*
class UserModel {
	public function createAccount(array $account) {
		$sql = "INSERT INTO user (prenom,nom,email,password,Adresse,Ville,CP,Telephone,created_at,updated_at) VALUES (:prenom,:nom,:email,:password,:Adresse,:Ville,:CP,:Telephone,:created_at,:updated_at)";
		$db = new Database();
		$db->executeSql($sql,$account);
	}
	public function exists($email) {
		$sql = 'SELECT idClient FROM Client WHERE email LIKE ?';
		$db = new Database();
		$result = $db->queryOne($sql,[$email]);
		if (!empty($result)) {
                return true;
                
            } else {
                return false;
            }
        return $result;    
	}
	public function processLogin($email,$password) {
		$sql = "SELECT * FROM Client WHERE email LIKE ? AND password LIKE ?";
		$db = new Database();
		$result = $db->queryOne($sql, [$email,$password]);
		return $result;
	}
	public function getUserByEmail($email) {
		$sql = "SELECT * FROM Client WHERE email = ?";
		$db = new Database();
		$result = $db->queryOne($sql, [$email]);
		return $result;
	}
	static function getUserById($id) {
		$sql = "SELECT * FROM Client WHERE id = ?";
		$db = new Database();
		$result = $db->queryOne($sql, [$id]);
		return $result;
	}
}	*/ -->