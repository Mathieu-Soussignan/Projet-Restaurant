<?php

class UserSession{

	public function __construct()
	{
		if(session_status()==PHP_SESSION_NONE)
		session_start();
	}

	public function create($idClient, $nom, $prenom, $email)
	{
		$_SESSION = [
			'id' 	=>$idClient,
			'nom' 	=>$nom,
			'prenom'=>$prenom,
			'email' =>$email
		];
	}

	public function destroy()
	{
		$_SESSION = [];
		session_destroy();
	}

	public function logged()
	{
		if (array_key_exists('id', $_SESSION))
		{
			return true;
		}else
			return false;
	}
}
//
?>

