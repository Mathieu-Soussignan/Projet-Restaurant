<?php

class LoginController
{
	public function httpGetMethod(Http $http, array $queryFields)
    {
       return ['_form' => new LoginForm()];
    }
    public function httpPostMethod(Http $http, array $formFields)
    {
        try
        {
            $userModel = new UserModel();
            $user = $userModel->findWithEmailPassword(
                $formFields['email'],
                $formFields['password']
            );

            //Construction de la session utilisateur.
            $userSession = new UserSession();
            $userSession->create(
                $user['idClient'],
                $user['prenom'],
                $user['nom'],
                $user['email']
            );

            $http->redirectTo('/');
        }
        catch(DomainException $e)
        {
                $form = new LoginForm();
                $form->bind($formFields);
                $form->setErrorMessage($e->getMessage());

            return ['_form'=>$form];
        }
    }
}

?>
