<?php

class LoginForm extends Form
{

	public function build()
	{
		echo "On passe par la ou pas? ";exit();
		// $this->addFormField('email');
		// var_dump($this);
		// $this->addFormField('password');

	}
}

?>