<?php

class InscriptionController 
{
    public function httpGetMethod(Http $http, array $queryFields)
    {

    }
    public function httpPostMethod(Http $http, array $formFields)
    {
        try{
            $userModel = new UserModel();
            $user = $userModel->create(
                $formFields['email'],
                $formFields['nom'],
                $formFields['prenom'],
                $formFields['password'],
                $formFields['telephone'],
                $formFields['adresse'],
                $formFields['cp'],
                $formFields['ville']
            );
            var_dump($formFields);

            $session = new UserSession();
            $session->create($user, $formFields['nom'], $formFields['prenom'], $formFields['email']);

            $http->redirectTo('/');

        }
        catch(DomainException $e){
            $form = new InscriptionForm();
            $form->bind($formFields);
            $form->setErrorMessage($e->getMessage());
            return ['_form'=>$form];
        }
    }
}