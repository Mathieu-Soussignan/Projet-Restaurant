<?php

class LogoutController
{
    public function httpGetMethod(Http $http, array $queryFields)
    {
		session_destroy();
		$http->redirectTo('/');

		$flash = new FlashBag();
		$flash->add('Au revoir');
		$http->redirectTo('/');
       
    }
    public function httpPostMethod(Http $http, array $formFields)
    {

    }
        
}